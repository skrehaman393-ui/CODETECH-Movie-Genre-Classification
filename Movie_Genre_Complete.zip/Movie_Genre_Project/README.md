
# Movie Genre Classification

**CODETECH Internship - Task 2**

**Name:** Shaik Rehaman

## Project Overview
This project classifies movie descriptions into five genres:
Action, Comedy, Drama, Romance, and Horror.

## Technologies Used
- Python
- Pandas
- Scikit-learn
- Matplotlib
- Seaborn
- TF-IDF
- Logistic Regression

## Project Files
- Dataset
- Trained ML model
- Model evaluation results
- Genre distribution graph
- Confusion matrix
- Prediction results

## How to Run
Open the Movie_Genre_Classification.ipynb notebook in Google Colab and run all cells.
